function setup() {
  createCanvas(450, 500);
  //angle mode ID
    angleMode(DEGREES);
  //print rain chance, not accurate math
var rainChance = 10;
  
  var realChance = percip(rainChance);
  
  print(realChance+"% chance of rain");
  
  function percip(r) {

	var newChance = r * 10;

	return newChance;
  }
}

function draw() {
  background("lightblue");
  //ground
    fill("green");
    rect (0, 440, 800, 500);
  
  for (var x = 20; x < width + 20; x += 40) {
		cloud(x, 125);
  }
  function cloud (x, y) {
  push ();
  
  translate (x, y);

	stroke(0);

	strokeWeight(55);
    
    scale(0.75);
    
	ellipse (100, -80 ,120, -150);
  
    fill("gray");
    
    stroke(0);

	strokeWeight(20);

    rotate(-2);
    
	ellipse (0, -110 ,120, -150);
    
    pop();
  }
    for (var x = 20; x < width + 20; x += 40) {
		rain(x, 125);
    }
  function rain (x, y) {
      push ();
    
    fill("blue");
  
    ellipse (122, 100, 30, 120);
     
   translate (x, y);
  
}

  

}