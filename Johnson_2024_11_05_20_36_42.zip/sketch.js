function setup() {
  createCanvas(500, 600);
 
}

function draw() { 
  
//my original polar pattern
  
//polarPentagon function
 setCenter(width/2, height/2);
    background(150);
     fill ("green");
    polarPentagons(5, 25, 50);
//polarTriangle function
    fill("red");
    polarTriangles(6, 50, 100);
//callback function
  resetMatrix();
  setCenter(width/4+250, height/4);
      fill("lightblue");
   polarEllipses(10, 0, 0, 100, function(...args) {
        fill(args[0]*40, args[0]*40, args[0]*40, 160);
        args[2] = args[0]*6;
        args[3] = args[0]*6;
        return args;    
      });
//callback function
   resetMatrix();
  setCenter(width/4, height/4+350);
   polarEllipses(10, 0, 0, 75, function(...args) {
        fill(args[0]*40, args[0]*40, args[0]*40, 160);
        args[2] = args[0]*6;
        args[3] = args[0]*6;
        return args;    
      });
//polarPentagon function
     resetMatrix();
  setCenter(width/1.5, height/4+350);
   fill("blue");
  polarPentagons(45, 75, 25);
//polarPentagon function
     resetMatrix();
  setCenter(width/5, height/4);
   fill("yellow");
  polarPentagons(45, 75, 25);
  //callback function
   resetMatrix();
  setCenter(width/2, height/2);
   polarEllipses(20, 5, 5, 200, function(...args) {
        fill(args[0]*40, args[0]*40, args[0]*40, 50);
        args[2] = args[0]*6;
        args[3] = args[0]*6;
        return args;    
      });
}