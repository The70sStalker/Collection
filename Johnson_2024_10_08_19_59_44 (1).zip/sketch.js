
var num = 60;

var x = [];

var y = [];

function setup() {

var x = [24, 40];
print(x.length); 
var y = [];
print(y.length); 
y[4] = 8; 
var num = 60;
print(num.length); 
  
  
     textAlign(CENTER); 
     textSize(500);
  
  
	createCanvas(440, 440);

	noStroke();

	for (var i = 0; i < num; i++) {

		x[i] = 3;

		y[i] = 3;

	}

}

function draw() {

	background("lightblue");
  
  fill("black");
  let word = "make the rain fall!"; 
    text(word, 200, 220);
  
  
  

	for (var i = num-1; i > 0; i--) {

		x[i] = x[i-1];

		y[i] = y[i-1];
	}

	x[0] = mouseX;

	y[0] = mouseY; 

	for (var i = 0; i < num; i++) {

        //color of rain
		fill("blue");
        //rain objecy
		ellipse(x[0], y[0], 40, 100);
     
      //grass
      fill("green");
      rect(0,400,500);
      
      //clouds
      fill("grey")
      ellipse(0,50,200);
       fill("grey")
      ellipse(200,0,200);
       fill("grey")
      ellipse(400,0,200);
      
	}
}